namespace Hamburgueria.Models
{
    public class Shake : Produto
    {
        
    }
}