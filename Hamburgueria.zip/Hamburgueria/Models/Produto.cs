namespace Hamburgueria.Models
{
    public class Produto
    {
        protected ulong Id {get;set;}
        public string Nome {get;set;}
        public double Preco {get;set;}
    }
}