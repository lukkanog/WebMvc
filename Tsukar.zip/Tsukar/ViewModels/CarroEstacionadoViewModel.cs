using System.Collections.Generic;
using Tsukar.Models;

namespace Tsukar.ViewModels
{
    public class CarroEstacionadoViewModel
    {
        public List<Modelo> Modelos {get;set;}
        public List<Marca> Marcas {get;set;}
    }
}